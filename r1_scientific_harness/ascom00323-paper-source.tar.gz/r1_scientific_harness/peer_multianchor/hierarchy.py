from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize

from .anchors import AnchorCatalog

METHOD_ORDER = ("TRGB", "JAGB")
DEFAULT_METHOD_FLOORS = {"TRGB": 0.038, "JAGB": 0.060}


@dataclass(frozen=True)
class ModelFit:
    model: str
    offsets: pd.Series
    offset_covariance: pd.DataFrame
    intrinsic_scatter: pd.Series
    chi2: float
    logdet_covariance: float
    neg2loglike: float
    n_parameters: int
    n_observations: int
    aic: float
    bic: float
    covariance: np.ndarray


def _method_sequence(method: np.ndarray) -> list[str]:
    observed = set(str(item).upper() for item in method)
    ordered = [item for item in METHOD_ORDER if item in observed]
    ordered.extend(sorted(observed.difference(ordered)))
    return ordered


def _design_matrix(method: np.ndarray, model: str) -> tuple[np.ndarray, list[str]]:
    n = len(method)
    methods = _method_sequence(method)
    if model == "M0":
        return np.empty((n, 0), dtype=float), []
    if model == "M1":
        return np.ones((n, 1), dtype=float), ["COMMON"]
    if model in {"M2", "M2R"}:
        return np.column_stack([(method == name).astype(float) for name in methods]), methods
    raise ValueError(f"unknown model: {model}")


def _fixed_covariance_fit(
    y: np.ndarray,
    covariance: np.ndarray,
    method: np.ndarray,
    model: str,
) -> tuple[np.ndarray, np.ndarray, float, float, float, list[str]]:
    y = np.asarray(y, dtype=float)
    covariance = np.asarray(covariance, dtype=float)
    method = np.asarray(method, dtype=str)
    if covariance.shape != (len(y), len(y)):
        raise ValueError("covariance shape does not match data")
    sign, logdet = np.linalg.slogdet(covariance)
    if sign <= 0:
        raise ValueError("covariance must be positive definite")
    cho = cho_factor(covariance, lower=True, check_finite=False)
    design, names = _design_matrix(method, model)
    if design.shape[1] == 0:
        beta = np.empty(0, dtype=float)
        beta_cov = np.empty((0, 0), dtype=float)
        residual = y
    else:
        precision_design = cho_solve(cho, design, check_finite=False)
        fisher = design.T @ precision_design
        beta_cov = np.linalg.inv(fisher)
        beta = beta_cov @ (design.T @ cho_solve(cho, y, check_finite=False))
        residual = y - design @ beta
    chi2 = float(residual @ cho_solve(cho, residual, check_finite=False))
    neg2loglike = float(chi2 + logdet + len(y) * np.log(2.0 * np.pi))
    return beta, beta_cov, chi2, float(logdet), neg2loglike, names


def fit_gls_model(
    y: np.ndarray,
    covariance: np.ndarray,
    method: np.ndarray,
    model: str,
) -> ModelFit:
    y = np.asarray(y, dtype=float)
    method = np.asarray(method, dtype=str)
    covariance = np.asarray(covariance, dtype=float)
    methods = _method_sequence(method)
    intrinsic = pd.Series(0.0, index=methods, dtype=float, name="intrinsic_scatter")
    fit_covariance = covariance.copy()

    if model == "M2R":
        method_masks = [(method == name) for name in methods]

        def objective(scatter: np.ndarray) -> float:
            candidate = covariance.copy()
            for value, mask in zip(scatter, method_masks, strict=True):
                candidate[np.diag_indices_from(candidate)] += mask.astype(float) * value**2
            return _fixed_covariance_fit(y, candidate, method, "M2R")[4]

        optimized = minimize(
            objective,
            x0=np.full(len(methods), 0.02),
            method="L-BFGS-B",
            bounds=[(0.0, 0.30)] * len(methods),
            options={"ftol": 1e-12, "gtol": 1e-10, "maxiter": 2000},
        )
        if not optimized.success:
            raise RuntimeError(f"intrinsic-scatter optimization failed: {optimized.message}")
        intrinsic = pd.Series(optimized.x, index=methods, dtype=float, name="intrinsic_scatter")
        for value, mask in zip(optimized.x, method_masks, strict=True):
            fit_covariance[np.diag_indices_from(fit_covariance)] += mask.astype(float) * value**2

    beta, beta_cov, chi2, logdet, neg2loglike, names = _fixed_covariance_fit(
        y, fit_covariance, method, model
    )
    offsets = pd.Series(beta, index=names, dtype=float, name="offset")
    offset_covariance = pd.DataFrame(beta_cov, index=names, columns=names, dtype=float)
    n_parameters = len(names) + (len(methods) if model == "M2R" else 0)
    n = len(y)
    return ModelFit(
        model=model,
        offsets=offsets,
        offset_covariance=offset_covariance,
        intrinsic_scatter=intrinsic,
        chi2=chi2,
        logdet_covariance=logdet,
        neg2loglike=neg2loglike,
        n_parameters=n_parameters,
        n_observations=n,
        aic=float(neg2loglike + 2 * n_parameters),
        bic=float(neg2loglike + n_parameters * np.log(n)),
        covariance=fit_covariance,
    )


@dataclass(frozen=True)
class AnchorHierarchy:
    observations: pd.DataFrame
    base_covariance: np.ndarray

    @classmethod
    def from_catalog(
        cls,
        catalog: AnchorCatalog,
        method_floors: dict[str, float] | None = None,
        same_host_cepheid_correlation: float = 1.0,
    ) -> "AnchorHierarchy":
        if not -1.0 <= same_host_cepheid_correlation <= 1.0:
            raise ValueError("same_host_cepheid_correlation must lie in [-1, 1]")
        floors = dict(DEFAULT_METHOD_FLOORS)
        if method_floors is not None:
            floors.update({str(key).upper(): float(value) for key, value in method_floors.items()})

        observations = catalog.table.copy().reset_index(drop=True)
        observations["delta_mu"] = (
            observations["mu_anchor"].astype(float) - observations["mu_cepheid"].astype(float)
        )
        n = len(observations)
        covariance = np.zeros((n, n), dtype=float)
        diagonal = observations["sigma_anchor"].astype(float).to_numpy() ** 2
        diagonal += observations["sigma_cepheid"].astype(float).to_numpy() ** 2
        covariance[np.diag_indices(n)] = diagonal

        for method in observations["method"].unique():
            floor = floors.get(str(method).upper(), 0.0)
            if floor < 0:
                raise ValueError("method floors must be non-negative")
            mask = observations["method"].to_numpy(dtype=str) == method
            covariance[np.ix_(mask, mask)] += floor**2

        for i in range(n):
            for j in range(i + 1, n):
                if observations.loc[i, "host"] != observations.loc[j, "host"]:
                    continue
                if observations.loc[i, "method"] == observations.loc[j, "method"]:
                    continue
                cepheid_covariance = (
                    same_host_cepheid_correlation
                    * float(observations.loc[i, "sigma_cepheid"])
                    * float(observations.loc[j, "sigma_cepheid"])
                )
                covariance[i, j] += cepheid_covariance
                covariance[j, i] += cepheid_covariance

        minimum_eigenvalue = float(np.linalg.eigvalsh(covariance)[0])
        if minimum_eigenvalue <= 0:
            raise ValueError(
                f"constructed anchor covariance is not positive definite: min eigenvalue={minimum_eigenvalue}"
            )
        return cls(observations=observations, base_covariance=covariance)

    def subset(self, hosts: set[str] | None = None) -> "AnchorHierarchy":
        if hosts is None:
            return self
        normalized = {str(host).upper().replace(" ", "") for host in hosts}
        mask = self.observations["host"].isin(normalized).to_numpy()
        indices = np.flatnonzero(mask)
        return AnchorHierarchy(
            observations=self.observations.loc[mask].reset_index(drop=True),
            base_covariance=self.base_covariance[np.ix_(indices, indices)],
        )

    def without_host(self, host: str) -> "AnchorHierarchy":
        normalized = str(host).upper().replace(" ", "")
        mask = (self.observations["host"] != normalized).to_numpy()
        indices = np.flatnonzero(mask)
        return AnchorHierarchy(
            observations=self.observations.loc[mask].reset_index(drop=True),
            base_covariance=self.base_covariance[np.ix_(indices, indices)],
        )

    def fit(self, model: str) -> ModelFit:
        return fit_gls_model(
            self.observations["delta_mu"].to_numpy(dtype=float),
            self.base_covariance,
            self.observations["method"].to_numpy(dtype=str),
            model=model,
        )

    def fit_all(self) -> dict[str, ModelFit]:
        return {model: self.fit(model) for model in ("M0", "M1", "M2", "M2R")}
