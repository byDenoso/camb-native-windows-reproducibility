"""PEER multi-anchor likelihood package."""
