from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

_REQUIRED = {
    "method", "host", "mu_anchor", "sigma_anchor", "mu_cepheid",
    "sigma_cepheid", "sn_cids", "source", "table", "zero_point",
}


def _split_cids(value: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in str(value).split(";") if part.strip())


@dataclass(frozen=True)
class AnchorCatalog:
    table: pd.DataFrame

    @classmethod
    def from_csvs(cls, *paths: Path | str) -> "AnchorCatalog":
        frames = [pd.read_csv(Path(path)) for path in paths]
        if not frames:
            raise ValueError("at least one anchor table is required")
        table = pd.concat(frames, ignore_index=True)
        missing = _REQUIRED.difference(table.columns)
        if missing:
            raise ValueError(f"anchor table missing columns: {sorted(missing)}")
        table = table.copy()
        table["method"] = table["method"].astype(str).str.upper().str.strip()
        table["host"] = table["host"].astype(str).str.upper().str.replace(" ", "", regex=False)
        table["sn_cids_tuple"] = table["sn_cids"].map(_split_cids)
        if table.duplicated(["method", "host"]).any():
            duplicates = table.loc[table.duplicated(["method", "host"], keep=False), ["method", "host"]]
            raise ValueError(f"duplicate method/host rows: {duplicates.to_dict('records')}")
        for column in ("sigma_anchor", "sigma_cepheid"):
            if (table[column].astype(float) <= 0).any():
                raise ValueError(f"{column} must be positive")
        if table["sn_cids_tuple"].map(len).eq(0).any():
            raise ValueError("every host must map to at least one SN CID")
        return cls(table=table)

    def hosts(self, method: str) -> set[str]:
        method = method.upper()
        return set(self.table.loc[self.table["method"] == method, "host"])

    @property
    def overlap_hosts(self) -> set[str]:
        methods = sorted(self.table["method"].unique())
        if not methods:
            return set()
        overlap = self.hosts(methods[0])
        for method in methods[1:]:
            overlap &= self.hosts(method)
        return overlap

    def validate_against_ladder(self, ladder_table: pd.DataFrame) -> dict[str, tuple[str, ...]]:
        calibrator_cids = set(
            ladder_table.loc[ladder_table["IS_CALIBRATOR"].astype(int) == 1, "CID"].astype(str)
        )
        result: dict[str, tuple[str, ...]] = {}
        missing: list[str] = []
        for row in self.table.itertuples(index=False):
            cids = tuple(row.sn_cids_tuple)
            absent = [cid for cid in cids if cid not in calibrator_cids]
            if absent:
                missing.extend(f"{row.method}:{row.host}:{cid}" for cid in absent)
            result[f"{row.method}:{row.host}"] = cids
        if missing:
            raise ValueError(f"anchor SN CIDs absent from official calibrators: {missing}")
        return result
