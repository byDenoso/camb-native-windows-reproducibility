from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.linalg import cho_factor, cho_solve

C_KM_S = 299_792.458


@dataclass(frozen=True)
class ProfileResult:
    mb_cepheid: float
    mb_hubble_flow: float
    delta_mb: float
    delta_mb_sigma: float
    chi2: float


@lru_cache(maxsize=4)
def _load_release(data_file: str, covariance_file: str) -> tuple[pd.DataFrame, np.ndarray]:
    table = pd.read_csv(data_file, sep=r"\s+")
    flat = np.loadtxt(covariance_file, skiprows=1)
    n = len(table)
    if flat.size != n * n:
        raise ValueError(f"covariance has {flat.size} values, expected {n*n}")
    return table, flat.reshape(n, n)


class DirectLadder:
    def __init__(self, table: pd.DataFrame, covariance: np.ndarray):
        self.n_total = len(table)
        mask = (table["IS_CALIBRATOR"].to_numpy(dtype=int) == 1) | (
            table["USED_IN_SH0ES_HF"].to_numpy(dtype=int) == 1
        )
        indices = np.flatnonzero(mask)
        selected = table.loc[mask].reset_index(drop=True)
        selected_cov = covariance[np.ix_(indices, indices)]

        self.table = selected
        self.covariance = selected_cov
        self.is_calibrator = selected["IS_CALIBRATOR"].to_numpy(dtype=bool)
        self.n_calibrator = int(self.is_calibrator.sum())
        self.n_hubble_flow = int((~self.is_calibrator).sum())
        self.n_ladder = len(selected)
        self.covariance_min_eigenvalue = float(np.linalg.eigvalsh(selected_cov)[0])

        self._cho = cho_factor(selected_cov, lower=True, check_finite=False)
        self._design = np.zeros((self.n_ladder, 2), dtype=float)
        self._design[self.is_calibrator, 0] = 1.0
        self._design[~self.is_calibrator, 1] = 1.0
        precision_design = cho_solve(self._cho, self._design, check_finite=False)
        self._fisher = self._design.T @ precision_design
        self._fisher_inv = np.linalg.inv(self._fisher)
        self._distance_shape_cache: OrderedDict[str, np.ndarray] = OrderedDict()
        self._distance_shape_cache_max = 8
        self._distance_cache_hits = 0
        self._distance_cache_computations = 0

    @classmethod
    def from_official_release(cls, root: Path | str) -> "DirectLadder":
        root = Path(root)
        data_file = root / "Pantheon+SH0ES.dat"
        covariance_file = root / "Pantheon+SH0ES_STAT+SYS.cov"
        table, covariance = _load_release(str(data_file), str(covariance_file))
        return cls(table, covariance)


    @classmethod
    def from_compiled(cls, root: Path | str) -> "DirectLadder":
        import hashlib, json
        root = Path(root).resolve()
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("schema") != "peer-direct-ladder-compiled/v1":
            raise ValueError("unsupported compiled direct-ladder schema")
        def checked(name: str) -> Path:
            spec = manifest["files"][name]
            path = (root / spec["path"]).resolve()
            if not path.is_relative_to(root):
                raise ValueError("compiled direct-ladder path escapes root")
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != spec["sha256"]:
                raise ValueError(f"compiled direct-ladder SHA-256 mismatch: {name}")
            return path
        obj = cls.__new__(cls)
        obj.n_total = int(manifest["n_total"])
        obj.n_ladder = int(manifest["n_ladder"])
        obj.n_calibrator = int(manifest["n_calibrator"])
        obj.n_hubble_flow = int(manifest["n_hubble_flow"])
        obj.covariance_min_eigenvalue = float(manifest["covariance_min_eigenvalue"])
        obj.table = pd.read_csv(checked("table.csv"))
        obj.is_calibrator = np.load(checked("is_calibrator.npy"), allow_pickle=False).astype(bool)
        obj.covariance = None
        factor = np.load(checked("cholesky.npy"), allow_pickle=False)
        obj._cho = (factor, True)
        obj._design = np.zeros((obj.n_ladder, 2), dtype=float)
        obj._design[obj.is_calibrator, 0] = 1.0
        obj._design[~obj.is_calibrator, 1] = 1.0
        precision_design = cho_solve(obj._cho, obj._design, check_finite=False)
        obj._fisher = obj._design.T @ precision_design
        obj._fisher_inv = np.linalg.inv(obj._fisher)
        obj._distance_shape_cache = OrderedDict()
        obj._distance_shape_cache_max = 8
        obj._distance_cache_hits = 0
        obj._distance_cache_computations = 0
        return obj

    @staticmethod
    def _angular_diameter_distance(z: float, H0: float, omega_m: float) -> float:
        if H0 <= 0:
            raise ValueError("H0 must be positive")
        if not 0 < omega_m < 1:
            raise ValueError("omega_m must lie in (0, 1)")
        integral = quad(
            lambda x: 1.0 / np.sqrt(omega_m * (1.0 + x) ** 3 + (1.0 - omega_m)),
            0.0,
            float(z),
            epsabs=1e-11,
            epsrel=1e-11,
            limit=100,
        )[0]
        comoving_distance = (C_KM_S / H0) * integral
        return comoving_distance / (1.0 + z)

    @staticmethod
    def _angular_diameter_distance_vector(z: np.ndarray, H0: float, omega_m: float) -> np.ndarray:
        if H0 <= 0:
            raise ValueError("H0 must be positive")
        if not 0 < omega_m < 1:
            raise ValueError("omega_m must lie in (0, 1)")
        z = np.asarray(z, dtype=float)
        nodes, weights = np.polynomial.legendre.leggauss(64)
        x = 0.5 * z[:, None] * (nodes[None, :] + 1.0)
        integrand = 1.0 / np.sqrt(omega_m * (1.0 + x) ** 3 + (1.0 - omega_m))
        integral = 0.5 * z * (integrand @ weights)
        return (C_KM_S / H0) * integral / (1.0 + z)

    def _dimensionless_distance_shape(self, omega_m: float) -> np.ndarray:
        if not 0 < omega_m < 1:
            raise ValueError("omega_m must lie in (0, 1)")
        key = float(omega_m).hex()
        cached = self._distance_shape_cache.get(key)
        if cached is not None:
            self._distance_shape_cache.move_to_end(key)
            self._distance_cache_hits += 1
            return cached
        zcmb = self.table["zHD"].to_numpy(dtype=float)
        indices = np.flatnonzero(~self.is_calibrator)
        z = zcmb[indices]
        nodes, weights = np.polynomial.legendre.leggauss(64)
        x = 0.5 * z[:, None] * (nodes[None, :] + 1.0)
        integrand = 1.0 / np.sqrt(
            omega_m * (1.0 + x) ** 3 + (1.0 - omega_m)
        )
        integral = 0.5 * z * (integrand @ weights)
        shape = C_KM_S * integral / (1.0 + z)
        shape.setflags(write=False)
        self._distance_shape_cache[key] = shape
        self._distance_shape_cache.move_to_end(key)
        self._distance_cache_computations += 1
        while len(self._distance_shape_cache) > self._distance_shape_cache_max:
            self._distance_shape_cache.popitem(last=False)
        return shape

    def distance_cache_info(self) -> dict[str, int]:
        return {
            "entries": len(self._distance_shape_cache),
            "hits": self._distance_cache_hits,
            "computations": self._distance_cache_computations,
        }

    def base_theory(self, H0: float, omega_m: float) -> np.ndarray:
        if H0 <= 0:
            raise ValueError("H0 must be positive")
        theory = np.empty(self.n_ladder, dtype=float)
        theory[self.is_calibrator] = self.table.loc[
            self.is_calibrator, "CEPH_DIST"
        ].to_numpy(dtype=float)
        zcmb = self.table["zHD"].to_numpy(dtype=float)
        zhel = self.table["zHEL"].to_numpy(dtype=float)
        indices = np.flatnonzero(~self.is_calibrator)
        da = self._dimensionless_distance_shape(omega_m) / float(H0)
        theory[indices] = 5.0 * np.log10(
            (1.0 + zcmb[indices]) * (1.0 + zhel[indices]) * da
        ) + 25.0
        return theory

    def profile_mb(self, H0: float, omega_m: float) -> ProfileResult:
        theory = self.base_theory(H0=H0, omega_m=omega_m)
        observed_minus_theory = self.table["m_b_corr"].to_numpy(dtype=float) - theory
        rhs = self._design.T @ cho_solve(
            self._cho, observed_minus_theory, check_finite=False
        )
        beta = self._fisher_inv @ rhs
        residual = observed_minus_theory - self._design @ beta
        chi2 = float(residual @ cho_solve(self._cho, residual, check_finite=False))
        delta_vector = np.array([1.0, -1.0])
        delta_sigma = float(np.sqrt(delta_vector @ self._fisher_inv @ delta_vector))
        return ProfileResult(
            mb_cepheid=float(beta[0]),
            mb_hubble_flow=float(beta[1]),
            delta_mb=float(beta[0] - beta[1]),
            delta_mb_sigma=delta_sigma,
            chi2=chi2,
        )
